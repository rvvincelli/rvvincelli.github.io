unset LIBJPG && unset LIBTIFF && unset LIBPNG
cd $PS2DEV/gsKit && make clean && make all && make install

