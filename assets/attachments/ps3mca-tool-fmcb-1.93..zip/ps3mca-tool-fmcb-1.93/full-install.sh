#!/bin/bash

echo "--- Free MC Boot loader v1.8c multi region/model installation ---"

# sign the kelf for memory card
echo "Signing boot kelf..."
./ps3mca-tool -k fmcb-install/FMCB.KELF fmcb-install/SFMCB.KELF &> /dev/null || { echo "ERROR: failed to sign boot kelf"; exit 1; }

# create all needed dirs
echo "Creating necessary directories..."
./ps3mca-tool -mkdir /BOOT &> /dev/null || { echo "ERROR: failed to create 'BOOT' directory"; exit 1; }
./ps3mca-tool -mkdir /BAEXEC-SYSTEM &> /dev/null || { echo "ERROR: failed to create 'BAEXEC-SYSTEM' directory"; exit 1; }
./ps3mca-tool -mkdir /BEEXEC-SYSTEM &> /dev/null || { echo "ERROR: failed to create 'BEEXEC-SYSTEM' directory"; exit 1; }
./ps3mca-tool -mkdir /BIEXEC-SYSTEM &> /dev/null || { echo "ERROR: failed to create 'BIEXEC-SYSTEM' directory"; exit 1; }
./ps3mca-tool -mkdir /SYS-CONF &> /dev/null || { echo "ERROR: failed to create 'SYS-CONF' directory"; exit 1; }

# copy the signed kelf to mc
echo "Copying signed boot kelf..."
./ps3mca-tool -in fmcb-install/SFMCB.KELF /BOOT/SFMCB.KELF &> /dev/null || { echo "ERROR: failed to copy signed kelf"; exit 1; }

# write all required files
echo "Copying default configuration file..."
./ps3mca-tool -in fmcb-install/SYS-CONF/FREEMCB.CNF /SYS-CONF/FREEMCB.CNF &> /dev/null || { echo "ERROR: failed to copy default connfiguration file"; exit 1; }
echo "Copying FMCB configurator..."
./ps3mca-tool -in fmcb-install/SYS-CONF/FMCB_CFG.ELF /SYS-CONF/FMCB_CFG.ELF &> /dev/null || { echo "ERROR: failed to copy FMCB configurator"; exit 1; }
echo "Copying USB modules..."
./ps3mca-tool -in fmcb-install/SYS-CONF/USBD.IRX /SYS-CONF/USBD.IRX &> /dev/null || { echo "ERROR: failed to copy 'USBD.IRX'"; exit 1; }
./ps3mca-tool -in fmcb-install/SYS-CONF/USBHDFSD.IRX /SYS-CONF/USBHDFSD.IRX &> /dev/null || { echo "ERROR: failed to copy 'USBHDFSD.IRX'"; exit 1; }
echo "Copying FMCB icons..."
./ps3mca-tool -in fmcb-install/BREXEC-SYSTEM/icon.sys /BAEXEC-SYSTEM/icon.sys &> /dev/null || { echo "ERROR: failed to copy 'icon.sys'"; exit 1; }
./ps3mca-tool -in fmcb-install/BREXEC-SYSTEM/FMCB.icn /BAEXEC-SYSTEM/FMCB.icn &> /dev/null || { echo "ERROR: failed to copy 'FMCB.icn'"; exit 1; }
echo "Copying BOOT folder icons..."
./ps3mca-tool -in fmcb-install/BOOT/icon.sys /BOOT/icon.sys &> /dev/null || { echo "ERROR: failed to copy 'icon.sys'"; exit 1; }
./ps3mca-tool -in fmcb-install/BOOT/BOOT.icn /BOOT/BOOT.icn &> /dev/null || { echo "ERROR: failed to copy 'BOOT.icn'"; exit 1; }
echo "Copying SYS-CONF folder icons..."
./ps3mca-tool -in fmcb-install/SYS-CONF/icon.sys /SYS-CONF/icon.sys &> /dev/null || { echo "ERROR: failed to copy 'icon.sys'"; exit 1; }
./ps3mca-tool -in fmcb-install/SYS-CONF/sysconf.icn /SYS-CONF/sysconf.icn &> /dev/null || { echo "ERROR: failed to copy 'sysconf.icn'"; exit 1; }

# write external homebrew apps
echo "Copying uLaunchElf..."
./ps3mca-tool -in fmcb-install/BOOT/BOOT.ELF /BOOT/BOOT.ELF &> /dev/null || { echo "ERROR: failed to copy uLaunchElf"; exit 1; }

# now crosslink dummy files to kelf to make multi region/model hack
echo "Cross-linking files for multi region/model installation..."
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BAEXEC-SYSTEM/osd120.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BAEXEC-SYSTEM/osd130.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BAEXEC-SYSTEM/osdmain.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BEEXEC-SYSTEM/osd130.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BEEXEC-SYSTEM/osdmain.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BIEXEC-SYSTEM/osdsys.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BIEXEC-SYSTEM/osd110.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BIEXEC-SYSTEM/osd120.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BIEXEC-SYSTEM/osd130.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BOOT/SFMCB.KELF /BIEXEC-SYSTEM/osdmain.elf &> /dev/null || { echo "ERROR: failed to cross-link 'SFMCB.KELF'"; exit 1; }
./ps3mca-tool -cl /BAEXEC-SYSTEM/icon.sys /BEEXEC-SYSTEM/icon.sys &> /dev/null || { echo "ERROR: failed to cross-link 'icon.sys'"; exit 1; }
./ps3mca-tool -cl /BAEXEC-SYSTEM/FMCB.icn /BEEXEC-SYSTEM/FMCB.icn &> /dev/null || { echo "ERROR: failed to cross-link 'FMCB.icn'"; exit 1; }
./ps3mca-tool -cl /BAEXEC-SYSTEM/icon.sys /BIEXEC-SYSTEM/icon.sys &> /dev/null || { echo "ERROR: failed to cross-link 'icon.sys'"; exit 1; }
./ps3mca-tool -cl /BAEXEC-SYSTEM/FMCB.icn /BIEXEC-SYSTEM/FMCB.icn &> /dev/null || { echo "ERROR: failed to cross-link 'FMCB.icn'"; exit 1; }

echo "Installation complete!"

