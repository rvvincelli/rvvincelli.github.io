#!/bin/bash

# format the memory card
echo "Formatting memory card..."
./ps3mca-tool --mc-format &> /dev/null || { echo "ERROR: failed to format"; exit 1; }

echo "Done!"

