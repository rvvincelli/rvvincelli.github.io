# Example PySpark on K8s application

This is a very simple program intended as a canary test and inspiration for advanced programs. When in doubt, always refer to the official Spark documentation.

Build:
`docker build -t aksblog/spark-example .`

Tag:
`docker tag aksblog/spark-example aksblog.azurecr.io/aksblog/spark-example`

Push:
`docker push aksblog.azurecr.io/aksblog/spark-example`

Then refer the image name `aksblog.azurecr.io/aksblog/spark-example` in `spark.properties`.
